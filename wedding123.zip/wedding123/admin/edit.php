<?php
session_start();
require '../firebase/firebase.php';  // Pastikan file ini menginisialisasi $firebase dengan benar

// Check admin login
if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header('Location: login.php');
    exit();
}

// Check for ID parameter
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Get wedding data by ID
        $wedding_data = $firebase->getReference("wedding-data")->getValue();

        if (!$wedding_data) {
            echo "<div class='alert alert-danger'>Data tidak ditemukan.</div>";
        }
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Terjadi kesalahan: " . $e->getMessage() . "</div>";
    }
} else {
    die("ID tidak ditemukan.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate date inputs
    $eventDate = $_POST['event_date'];
    if (!DateTime::createFromFormat('Y-m-d', $eventDate)) {
        die("Format tanggal tidak valid.");
    }

    // Prepare data structure
    $data = [
        "couple" => [
            "groom" => [
                "name" => $_POST['groom_name'],
                "description" => $_POST['groom_description'],
                "father" => $_POST['groom_father'],
                "mother" => $_POST['groom_mother']
            ],
            "bride" => [
                "name" => $_POST['bride_name'],
                "description" => $_POST['bride_description'],
                "father" => $_POST['bride_father'],
                "mother" => $_POST['bride_mother']
            ]
        ],
        "event" => [
            "date" => $eventDate,
            "location" => [
                "name" => $_POST['venue_name'],
                "address" => $_POST['venue_address'],
                "maps_url" => $_POST['maps_url']
            ],
            "ceremony" => [
                "time" => $_POST['ceremony_time'],
                "description" => $_POST['ceremony_description']
            ],
            "reception" => [
                "time" => $_POST['reception_time'],
                "description" => $_POST['reception_description']
            ]
        ],
        "theme" => [
            "current" => $_POST['theme'],
            "countdown" => $_POST['countdown_theme']
        ],
        "countdown" => [
            "year" => (int)$_POST['countdown_year'],
            "month" => (int)$_POST['countdown_month'],
            "day" => (int)$_POST['countdown_day'],
            "hour" => (int)$_POST['countdown_hour']
        ]
    ];

    try {
        // Update data in Firebase
        $firebase->getReference("wedding-data")->update($data);
        
        // Jika diperlukan update terpisah untuk tema
        $firebase->getReference('wedding-data/theme')->update([
            'current' => $_POST['theme'],
            'countdown' => $_POST['countdown_theme']
        ]);
        
        header("Location: index.php?status=updated");
        exit();
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>Terjadi kesalahan: " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <title>Edit Undangan Pernikahan</title>
    
    <style>
        :root {
            --primary-color:rgb(0, 72, 255);
            --primary-light:rgb(255, 255, 255);
            --primary-dark:rgb(9, 0, 136);
            --accent-color:rgb(56, 162, 255);
            --accent-light:rgb(0, 115, 255);
            --secondary-color:rgb(0, 225, 255);
            --text-dark: #2c3e50;
            --text-light: #7f8c8d;
            --border-color: #ecf0f1;
            --card-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
        }
        
        body {
            background-color: #f9f9f9;
            background-image: linear-gradient(135deg, #f5f7fa 0%, #e8eaed 100%);
            font-family: 'Poppins', 'Segoe UI', Roboto, Arial, sans-serif;
            color: var(--text-dark);
            min-height: 100vh;
            padding: 2rem 0;
        }
        
        /* Import Google Fonts */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        .edit-container {
            background-color: white;
            border-radius: 24px;
            box-shadow: var(--card-shadow);
            padding: 3rem;
            margin: 1rem auto;
            max-width: 900px;
            position: relative;
            overflow: hidden;
        }
        
        .edit-container::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 8px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
        }
        
        .form-label {
            font-weight: 500;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
            font-size: 0.95rem;
        }
        
        .form-control, .form-select {
            border-radius: 12px;
            border: 1px solid var(--border-color);
            padding: 0.75rem 1.2rem;
            font-size: 0.95rem;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.02);
            transition: all 0.25s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(142, 68, 173, 0.15);
        }
        
        .card {
            margin-bottom: 2rem;
            border: none;
            border-radius: 16px;
            box-shadow: var(--card-shadow);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }
        
        .card-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
            border-bottom: 0;
            padding: 1.2rem 1.8rem;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        
        .card-body {
            padding: 2rem;
            background-color: white;
        }
        
        .page-title {
            font-weight: 700;
            margin-bottom: 2.5rem;
            position: relative;
            display: inline-block;
            color: var(--primary-dark);
        }
        
        .page-title::after {
            content: "";
            position: absolute;
            bottom: -10px;
            left: 0;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
            border-radius: 2px;
        }
        
        h5 {
            font-weight: 600;
            display: flex;
            align-items: center;
        }
        
        h6 {
            color: var(--primary-color);
            font-weight: 600;
            margin-bottom: 1.5rem;
            padding-bottom: 0.8rem;
            position: relative;
        }
        
        h6::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 3px;
            background-color: var(--secondary-color);
            border-radius: 2px;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border: none;
            border-radius: 12px;
            padding: 0.8rem 2rem;
            font-weight: 600;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 15px rgba(142, 68, 173, 0.3);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(142, 68, 173, 0.4);
        }
        
        .form-text {
            color: var(--text-light);
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }
        
        .mb-3 {
            margin-bottom: 1.5rem !important;
        }
        
        /* Special styling for couple info */
        .couple-info {
            position: relative;
        }
        
        .couple-info::after {
            content: "❤";
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            color: white;
            font-size: 1.8rem;
            z-index: 2;
            background: linear-gradient(135deg, var(--accent-color), var(--primary-color));
            width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        
        /* Section dividers */
        .section-divider {
            display: flex;
            align-items: center;
            margin: 2.5rem 0;
        }
        
        .divider-line {
            flex-grow: 1;
            height: 1px;
            background-color: var(--border-color);
        }
        
        .divider-icon {
            padding: 0 1.5rem;
            color: var(--primary-color);
            font-size: 1.2rem;
        }
        
        /* Card header icon styling */
        .card-header i {
            margin-right: 10px;
            font-size: 1.2rem;
        }
        
        /* Input groups */
        .input-group {
            border-radius: 12px;
            overflow: hidden;
        }
        
        .input-group-text {
            background-color: var(--primary-light);
            border-color: var(--border-color);
            color: var(--primary-color);
        }
        
        /* Countdown styling */
        .countdown-container {
            background-color: var(--primary-light);
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 1rem;
        }
        
        .countdown-inputs {
            display: flex;
            gap: 10px;
        }
        
        .countdown-inputs .form-control {
            text-align: center;
            font-weight: 500;
        }
        
        .countdown-label {
            font-size: 0.8rem;
            text-align: center;
            color: var(--text-light);
            margin-top: 5px;
        }
        
        /* Animation for save button */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        .save-btn-container {
            position: relative;
        }
        
        .save-btn-container::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: 12px;
            padding: 3px;
            background: linear-gradient(45deg, var(--accent-color), var(--primary-color), var(--accent-color));
            -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
            -webkit-mask-composite: xor;
            mask-composite: exclude;
            opacity: 0;
            transition: opacity 0.3s ease;
        }
        
        .save-btn-container:hover::before {
            opacity: 1;
        }
        
        .save-button {
            animation: pulse 2s infinite;
            padding: 1rem 3rem;
            font-size: 1.1rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="edit-container">
            <h2 class="text-center page-title">
                <i class="bi bi-person-circle me-2 text-danger"></i>Edit Undangan Pernikahan
            </h2>

            <form method="POST">
                <!-- Couple Information -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-people-fill"></i>Informasi Pengantin</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-4 couple-info">
                            <!-- Groom -->
                            <div class="col-md-6">
                                <h6><i class="bi bi-person-fill me-2"></i>Pengantin Pria</h6>
                                <div class="mb-3">
                                    <label class="form-label">Nama Lengkap</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                                        <input type="text" class="form-control" name="groom_name" 
                                            value="<?= htmlspecialchars($wedding_data['couple']['groom']['name']) ?>" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Deskripsi</label>
                                    <textarea class="form-control" name="groom_description" rows="3" placeholder="Ceritakan sedikit tentang pengantin pria..."><?= htmlspecialchars($wedding_data['couple']['groom']['description']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nama Ayah</label>
                                    <input type="text" class="form-control" name="groom_father" 
                                        value="<?= htmlspecialchars($wedding_data['couple']['groom']['father']) ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nama Ibu</label>
                                    <input type="text" class="form-control" name="groom_mother" 
                                        value="<?= htmlspecialchars($wedding_data['couple']['groom']['mother']) ?>">
                                </div>
                            </div>

                            <!-- Bride -->
                            <div class="col-md-6">
                                <h6><i class="bi bi-person-heart me-2"></i>Pengantin Wanita</h6>
                                <div class="mb-3">
                                    <label class="form-label">Nama Lengkap</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-person"></i></span>
                                        <input type="text" class="form-control" name="bride_name" 
                                            value="<?= htmlspecialchars($wedding_data['couple']['bride']['name']) ?>" required>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Deskripsi</label>
                                    <textarea class="form-control" name="bride_description" rows="3" placeholder="Ceritakan sedikit tentang pengantin wanita..."><?= htmlspecialchars($wedding_data['couple']['bride']['description']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nama Ayah</label>
                                    <input type="text" class="form-control" name="bride_father" 
                                        value="<?= htmlspecialchars($wedding_data['couple']['bride']['father']) ?>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nama Ibu</label>
                                    <input type="text" class="form-control" name="bride_mother" 
                                        value="<?= htmlspecialchars($wedding_data['couple']['bride']['mother']) ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="section-divider">
                    <div class="divider-line"></div>
                    <div class="divider-icon"><i class="bi bi-stars"></i></div>
                    <div class="divider-line"></div>
                </div>

                <!-- Event Details -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-calendar-event-fill"></i>Detail Acara</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label">Tanggal Acara</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-calendar3"></i></span>
                                    <input type="date" class="form-control" name="event_date" 
                                        value="<?= htmlspecialchars($wedding_data['event']['date']) ?>" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Nama Tempat</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-building"></i></span>
                                    <input type="text" class="form-control" name="venue_name" 
                                        value="<?= htmlspecialchars($wedding_data['event']['location']['name']) ?>" required>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Alamat Lengkap</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-geo-alt"></i></span>
                                    <textarea class="form-control" name="venue_address" rows="2"><?= htmlspecialchars($wedding_data['event']['location']['address']) ?></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Link Google Maps</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-pin-map"></i></span>
                                    <input type="text" class="form-control" name="maps_url" 
                                        value="<?= htmlspecialchars($wedding_data['event']['location']['maps_url']) ?>">
                                </div>
                                <div class="form-text">
                                    <i class="bi bi-info-circle me-1"></i>Gunakan format URL embed (https://www.google.com/maps/embed?...)
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Schedule -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-clock-fill"></i>Jadwal Acara</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <h6><i class="bi bi-ring me-2"></i>Akad Nikah</h6>
                                <div class="mb-3">
                                    <label class="form-label">Waktu</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-clock"></i></span>
                                        <input type="text" class="form-control" name="ceremony_time" placeholder="Contoh: 08:00 - 10:00 WIB"
                                            value="<?= htmlspecialchars($wedding_data['event']['ceremony']['time']) ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Deskripsi</label>
                                    <textarea class="form-control" name="ceremony_description" rows="2" placeholder="Informasi tambahan tentang akad..."><?= htmlspecialchars($wedding_data['event']['ceremony']['description']) ?></textarea>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6><i class="bi bi-cup-hot-fill me-2"></i>Resepsi</h6>
                                <div class="mb-3">
                                    <label class="form-label">Waktu</label>
                                    <div class="input-group">
                                        <span class="input-group-text"><i class="bi bi-clock"></i></span>
                                        <input type="text" class="form-control" name="reception_time" placeholder="Contoh: 11:00 - 14:00 WIB"
                                            value="<?= htmlspecialchars($wedding_data['event']['reception']['time']) ?>">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Deskripsi</label>
                                    <textarea class="form-control" name="reception_description" rows="2" placeholder="Informasi tambahan tentang resepsi..."><?= htmlspecialchars($wedding_data['event']['reception']['description']) ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Theme and Countdown -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="bi bi-palette-fill"></i>Pengaturan Tema & Countdown</h5>
                    </div>
                    <div class="card-body">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label">Tema Undangan</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-palette"></i></span>
                                    <select class="form-select" name="theme">
                                        <option value="tema1" <?= $wedding_data['theme']['current'] === 'tema1' ? 'selected' : '' ?>>Tema 1 - Elegant</option>
                                        <option value="tema2" <?= $wedding_data['theme']['current'] === 'tema2' ? 'selected' : '' ?>>Tema 2 - Romantic</option>
                                        <option value="tema3" <?= $wedding_data['theme']['current'] === 'tema3' ? 'selected' : '' ?>>Tema 3 - Modern</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Tema Countdown</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="bi bi-hourglass-split"></i></span>
                                    <select class="form-select" name="countdown_theme">
                                        <option value="tema1" <?= isset($wedding_data['theme']['countdown']) && $wedding_data['theme']['countdown'] === 'tema1' ? 'selected' : '' ?>>Tema 1 - Classic</option>
                                        <option value="tema2" <?= isset($wedding_data['theme']['countdown']) && $wedding_data['theme']['countdown'] === 'tema2' ? 'selected' : '' ?>>Tema 2 - Minimalist</option>
                                        <option value="tema3" <?= isset($wedding_data['theme']['countdown']) && $wedding_data['theme']['countdown'] === 'tema3' ? 'selected' : '' ?>>Tema 3 - Colorful</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="col-md-12">
                                <label class="form-label">Pengaturan Countdown</label>
                                <div class="countdown-container">
                                    <p class="mb-3"><i class="bi bi-info-circle me-2"></i>Atur waktu mulai hitungan mundur untuk hari spesial Anda</p>
                                    <div class="row g-3">
                                        <div class="col-md-3 col-6">
                                            <input type="number" class="form-control" name="countdown_year" placeholder="Tahun" 
                                                value="<?= htmlspecialchars($wedding_data['countdown']['year']) ?>" required>
                                            <div class="countdown-label">Tahun</div>
                                        </div>
                                        <div class="col-md-3 col-6">
                                            <input type="number" class="form-control" name="countdown_month" placeholder="Bulan" min="1" max="12"
                                                value="<?= htmlspecialchars($wedding_data['countdown']['month']) ?>" required>
                                            <div class="countdown-label">Bulan</div>
                                        </div>
                                        <div class="col-md-3 col-6">
                                            <input type="number" class="form-control" name="countdown_day" placeholder="Tanggal" min="1" max="31"
                                                value="<?= htmlspecialchars($wedding_data['countdown']['day']) ?>" required>
                                            <div class="countdown-label">Tanggal</div>
                                        </div>
                                        <div class="col-md-3 col-6">
                                            <input type="number" class="form-control" name="countdown_hour" placeholder="Jam" min="0" max="23"
                                                value="<?= htmlspecialchars($wedding_data['countdown']['hour']) ?>" required>
                                            <div class="countdown-label">Jam</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-5 save-btn-container">
                    <button type="submit" class="btn btn-primary btn-lg save-button">
                        <i class="bi bi-save me-2"></i>Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Optional: Add some interactivity
        document.addEventListener('DOMContentLoaded', function() {
            // Add a simple animation to the cards when they come into view
            const cards = document.querySelectorAll('.card');
            
            // Simple function to check if element is in viewport
            function isInViewport(element) {
                const rect = element.getBoundingClientRect();
                return (
                    rect.top >= 0 &&
                    rect.left >= 0 &&
                    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
                    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
                );
            }
            
            // Add animation class when scrolling
            function checkCards() {
                cards.forEach(card => {
                    if (isInViewport(card)) {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }
                });
            }
            
            // Initial styles
            cards.forEach(card => {
                card.style.opacity = '0';
                card.style.transform = 'translateY(20px)';
                card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            });
            
            // Check on load and scroll
            window.addEventListener('scroll', checkCards);
            window.addEventListener('resize', checkCards);
            
            // Initial check
            setTimeout(checkCards, 100);
        });
    </script>
</body>
</html>